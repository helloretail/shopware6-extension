import template from './sw-cms-block-hello-retail.html.twig';
import './sw-cms-block-hello-retail.scss'

Shopware.Component.register('sw-cms-block-hello-retail', {
    template
});
