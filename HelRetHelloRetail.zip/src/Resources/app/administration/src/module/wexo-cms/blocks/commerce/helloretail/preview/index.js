import template from './sw-cms-preview-hello-retail.html.twig';

Shopware.Component.register('sw-cms-preview-hello-retail', {
    template
});
