Shopware.Service('helloRetailTemplateService').registerExportTemplate({
    name: 'customer',
    headerTemplate: null,
    bodyTemplate: null,
    footerTemplate: null,
    file: null,
    associations: []
});
